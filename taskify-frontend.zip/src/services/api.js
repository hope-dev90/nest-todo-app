import axios from 'axios';

const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:3000',
});

// Attach JWT token to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Auto logout on 401
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

// ── Auth ──────────────────────────────────────────
export const authApi = {
  login: (email, password) =>
    api.post('/auth/login', { email, password }),

  register: (name, email, password) =>
    api.post('/auth/register', { name, email, password }),

  forgotPassword: (email) =>
    api.post('/auth/forgot-password', { email }),
};

// ── Notes ─────────────────────────────────────────
export const notesApi = {
  getAll: (search) =>
    api.get('/notes', { params: search ? { search } : {} }),

  getOne: (id) =>
    api.get(`/notes/${id}`),

  create: (data) =>
    api.post('/notes', data),

  update: (id, data) =>
    api.patch(`/notes/${id}`, data),

  delete: (id) =>
    api.delete(`/notes/${id}`),
};

export default api;
