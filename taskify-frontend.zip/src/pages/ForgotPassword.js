import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { authApi } from '../services/api';

export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async e => {
    e.preventDefault();
    setLoading(true); setError('');
    try {
      await authApi.forgotPassword(email);
      setSent(true);
    } catch (e) {
      setError(e.response?.data?.message || 'Something went wrong');
    } finally { setLoading(false); }
  };

  return (
    <div className="auth-root">
      <div className="auth-panel">
        <div style={{ position: 'relative', zIndex: 1, textAlign: 'center', color: 'white' }}>
          <div style={{ fontSize: 56, marginBottom: 24 }}>🔑</div>
          <h2 style={{ fontFamily: "'Clash Display', sans-serif", fontSize: 28, fontWeight: 700, marginBottom: 12 }}>
            Reset your password
          </h2>
          <p style={{ fontSize: 15, opacity: 0.8, maxWidth: 280, margin: '0 auto' }}>
            We'll send you a secure link to reset your password in seconds.
          </p>
        </div>
      </div>

      <div className="auth-form-side">
        <div className="auth-box animate-fadeUp">
          <div className="auth-logo">
            <div className="logo-icon">📋</div>
            <span>Taskify</span>
          </div>

          {sent ? (
            <div style={{ textAlign: 'center', padding: '2rem 0' }}>
              <div style={{ fontSize: 48, marginBottom: 16 }}>📬</div>
              <h2 style={{ fontSize: 22, fontWeight: 700, marginBottom: 8 }}>Check your inbox</h2>
              <p style={{ color: 'var(--text-secondary)', fontSize: 14, marginBottom: 1.5 + 'rem' }}>
                We sent a password reset link to <strong>{email}</strong>
              </p>
              <Link to="/login" style={{ color: 'var(--primary)', fontWeight: 600, fontSize: 14 }}>
                ← Back to sign in
              </Link>
            </div>
          ) : (
            <>
              <h1 className="auth-title">Forgot password?</h1>
              <p className="auth-subtitle">Enter your email and we'll send a reset link</p>
              {error && <div className="auth-error">{error}</div>}
              <form onSubmit={handleSubmit}>
                <div className="form-group">
                  <label className="form-label">Email address</label>
                  <input
                    className="form-input"
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    required
                  />
                </div>
                <button className="btn-primary" type="submit" disabled={loading}>
                  {loading ? <span className="spinner" /> : 'Send reset link'}
                </button>
              </form>
              <p className="auth-switch">
                <Link to="/login">← Back to sign in</Link>
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
